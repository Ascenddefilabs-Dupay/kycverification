import React from 'react';
import PersonalDetailsForm from './PersonalDetailsForm';

function App() {
  return (
    <div >
      <PersonalDetailsForm />
    </div>
  );
}

export default App;
